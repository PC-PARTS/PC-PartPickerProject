from django.apps import AppConfig


class BuilderConfig(AppConfig):
    name = 'builder'
